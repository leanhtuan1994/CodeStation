This is the MEDIAL activity plugin for Moodle 2.x.

Installation
------------

1 - Copy the contents of the zip file which contains this readme.txt into the moodle/mod directory of your
    Moodle installation.
2 - Login to your Moodle system as an administrator.
3 - Click the "Notifications" link in the "Administration" block.
4 - Follow the on-screen instructions.
5 - After installation, you will be presented with a configuration screen where you can enter the URL
    of your MEDIAL System. If this doesn't happen, please navigate to
    Site Administration>Plugins>Activity Modules>MEDIAL
    and enter the details.


Module provided by Streaming LTD http://www.streaming.co.uk
